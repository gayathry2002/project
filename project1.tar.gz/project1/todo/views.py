from django.shortcuts import render
from.models import*
from.forms import*

# Create your views here.
def index(request):
    model=Task.objects.all()
    form=Todo_form()
    if request.method == 'POST':
        if 'delete' in request.POST():
            key=request.POST.get('delete')
            m=Task.objects.get(id=key)
            m.delete()

    context=[]  
    context={
            'model':model,
            'form':form
        }
    return render(request,'index.html',context)
